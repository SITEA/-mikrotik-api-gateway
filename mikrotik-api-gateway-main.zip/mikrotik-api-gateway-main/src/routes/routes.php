<?php 

// ROTAS DE LOGIN
include __DIR__ . '/login.php';

// ROTAS DA HOME
include __DIR__ . '/home.php';

//ROTAS DE API
include __DIR__ . '/api.php';

//ROTAS DE API
include __DIR__ . '/rest.php';

// ROTAS DE USUÁRIO
include __DIR__ . '/user.php';

//ROTAS DE MIKROTIK
include __DIR__ . '/mikrotik.php';

// ROTAS DE ERRO
include __DIR__ . '/error.php';